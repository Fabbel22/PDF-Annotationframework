﻿//
// Requires: jquery
//
"use strict";

$(function () {
	// Activate Popover Feature (and add fade out animation to popovers which appear on click)
	var jqPopoversClick = $('[data-toggle="popover"][data-trigger="click"]');
	jqPopoversClick.popover();
	jqPopoversClick.on("shown.bs.popover", function () {
		setTimeout(function () { jqPopoversClick.popover("hide"); }, 1000);
	});
	var jqPopoversHover = $('[data-toggle="popover"][data-trigger="hover"]');
	jqPopoversHover.popover();
});

function addAlert(cssClass, title, message) {
	var myAlert = $('<div class="alert" role="alert"></div>"')
		.addClass(cssClass)
		.append($('<strong></strong>').text(title))
		.append($('<span></span>').text(message))
		.append($('<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>'));

	$('body > div.container').prepend(myAlert);

	return myAlert;
}

/**
 * Confirmation dialog options.
 * 
 * @typedef ConfirmationDialogOptions
 * @prop {string} title The dialog title.
 * @prop {string} text The dialog's main text.
 * @prop {string} okButtonText OK button text.
 * @prop {string} cancelButtonText Cancel button text.
 * @prop {boolean} isDanger Indicates whether the "OK" button should be red.
 */

/**
 * Shows a modal confirmation dialog.
 * @param {ConfirmationDialogOptions} options Dialog options.
 * @param {Function} okHandler Callback function that is called in case the user presses the "OK" button.
 */
function confirmFancy(options, okHandler) {
	function btnOK_click() {
		$("#dlgMsgBox").modal("hide");
		okHandler();
	}
	if (options.text) {
		document.getElementById("dlgMsgBoxBody").textContent = options.text;
	}
	if (options.title) {
		document.getElementById("dlgMsgBoxTitle").textContent = options.title;
	}
	var btnOK = document.getElementById("btnDlgMsgBoxOK");
	if (options.okButtonText) {
		btnOK.textContent = options.okButtonText;
	}
	if (options.cancelButtonText) {
		document.getElementById("btnDlgMsgBoxCancel").textContent = options.cancelButtonText;
	}
	if (options.isDanger) {
		btnOK.classList.remove("btn-primary");
		btnOK.classList.add("btn-danger");
	}
	btnOK.addEventListener("click", btnOK_click);
	function hiddenBsModal() {
		$("#dlgMsgBox").off("hidden.bs.modal", hiddenBsModal);
		btnOK.removeEventListener("click", btnOK_click);
	}
	$("#dlgMsgBox").on("hidden.bs.modal", hiddenBsModal);
	$("#dlgMsgBox").modal("show");
}
